#!/usr/bin/env python

"""
Copyright (c) 2006-2026 sqlmap developers (https://sqlmap.org)
See the file 'LICENSE' for copying permission
"""

from lib.core.enums import DBMS
from lib.core.settings import SNOWFLAKE_SYSTEM_DBS
from lib.core.unescaper import unescaper
from plugins.dbms.snowflake.enumeration import Enumeration
from plugins.dbms.snowflake.filesystem import Filesystem
from plugins.dbms.snowflake.fingerprint import Fingerprint
from plugins.dbms.snowflake.syntax import Syntax
from plugins.dbms.snowflake.takeover import Takeover
from plugins.generic.misc import Miscellaneous

class SnowflakeMap(Syntax, Fingerprint, Enumeration, Filesystem, Miscellaneous, Takeover):
    """
    This class defines Snowflake methods
    """

    def __init__(self):
        self.excludeDbsList = SNOWFLAKE_SYSTEM_DBS

        for cls in self.__class__.__bases__:
            cls.__init__(self)

    unescaper[DBMS.SNOWFLAKE] = Syntax.escape
